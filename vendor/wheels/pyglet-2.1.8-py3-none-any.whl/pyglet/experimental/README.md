Experimental modules
====================

This package contains experimental modules, which are included here for
wider testing and feedback. Anything contained within may be broken, refactored,
or removed without notice.